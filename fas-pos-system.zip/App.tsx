
import React, { useState, useEffect, useContext } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation, Outlet } from 'react-router-dom';
import { User } from './types';
import { dbService } from './services/dbService';
import { AuthContext } from './contexts/AuthContext';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import POS from './pages/POS';
import Products from './pages/Products';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Technicians from './pages/Technicians';
import Finance from './pages/Finance';
import Sidebar from './components/Sidebar';

const Layout = () => {
  const { user } = useContext(AuthContext);
  const location = useLocation();

  if (!user) return <Navigate to="/login" />;

  return (
    <div className="flex h-screen overflow-hidden bg-[#eef0f4]">
      <Sidebar user={user} activePath={location.pathname} />
      <main className="flex-1 overflow-y-auto p-6 relative">
        {/* Background Gradient Blurs */}
        <div className="fixed top-[-10%] left-[-10%] w-96 h-96 bg-fas-400/20 rounded-full blur-3xl pointer-events-none z-0" />
        <div className="fixed bottom-[-10%] right-[-10%] w-96 h-96 bg-blue-400/20 rounded-full blur-3xl pointer-events-none z-0" />
        <div className="relative z-10 h-full">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

const AppContent = () => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('fas_session');
    if (savedUser) setUser(JSON.parse(savedUser));
  }, []);

  const login = (u: string, p: string) => {
    const foundUser = dbService.login(u, p);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('fas_session', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('fas_session');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/pos" element={<POS />} />
          <Route path="/products" element={<Products />} />
          <Route path="/technicians" element={<Technicians />} />
          <Route path="/finance" element={<Finance />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
      </Routes>
    </AuthContext.Provider>
  );
};

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
