import React from 'react';
import { motion } from 'framer-motion';

interface NeuButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'danger' | 'neutral';
  icon?: React.ReactNode;
}

export const NeuButton: React.FC<NeuButtonProps> = ({ 
  children, 
  variant = 'neutral', 
  icon, 
  className = '', 
  ...props 
}) => {
  let baseClasses = "flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all duration-200 outline-none select-none";
  let colorClasses = "";

  switch (variant) {
    case 'primary':
      colorClasses = "bg-fas-500 text-white shadow-[6px_6px_12px_#aebec0,-6px_-6px_12px_#ffffff] hover:bg-fas-600 active:shadow-[inset_4px_4px_8px_rgba(0,0,0,0.2),inset_-4px_-4px_8px_rgba(255,255,255,0.2)]";
      break;
    case 'danger':
      colorClasses = "bg-red-500 text-white shadow-[6px_6px_12px_#aebec0,-6px_-6px_12px_#ffffff] hover:bg-red-600 active:shadow-[inset_4px_4px_8px_rgba(0,0,0,0.2),inset_-4px_-4px_8px_rgba(255,255,255,0.2)]";
      break;
    default: // Neutral
      colorClasses = "bg-[#eef0f4] text-slate-700 shadow-neu-flat hover:translate-y-[-1px] active:shadow-neu-pressed active:translate-y-[1px]";
      break;
  }

  return (
    <motion.button
      whileTap={{ scale: 0.98 }}
      className={`${baseClasses} ${colorClasses} ${className}`}
      {...props}
    >
      {icon && <span className="text-lg">{icon}</span>}
      {children}
    </motion.button>
  );
};
