
import React, { useContext, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LayoutDashboard, ShoppingCart, Package, BarChart3, Settings, LogOut, Hexagon, Hammer, Briefcase, Bell } from 'lucide-react';
import { User, UserRole } from '../types';
import { AuthContext } from '../contexts/AuthContext';
import { dbService } from '../services/dbService';

interface SidebarProps {
  user: User;
  activePath: string;
}

const Sidebar: React.FC<SidebarProps> = ({ user, activePath }) => {
  const { logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [lowStockCount, setLowStockCount] = useState(0);

  useEffect(() => {
    const checkStock = () => {
        const lowStock = dbService.getLowStockProducts();
        setLowStockCount(lowStock.length);
    };
    
    checkStock();
    const interval = setInterval(checkStock, 5000); 
    return () => clearInterval(interval);
  }, []);

  const menuItems = [
    { path: '/', label: 'الرئيسية', icon: <LayoutDashboard size={20} />, roles: [UserRole.ADMIN, UserRole.CASHIER] },
    { path: '/pos', label: 'نقطة البيع', icon: <ShoppingCart size={20} />, roles: [UserRole.ADMIN, UserRole.CASHIER] },
    { path: '/finance', label: 'المالية والموارد البشرية', icon: <Briefcase size={20} />, roles: [UserRole.ADMIN] },
    { path: '/products', label: 'المنتجات والمخزون', icon: <Package size={20} />, roles: [UserRole.ADMIN], badge: lowStockCount }, 
    { path: '/technicians', label: 'الصنايعية', icon: <Hammer size={20} />, roles: [UserRole.ADMIN] }, 
    { path: '/reports', label: 'التقارير', icon: <BarChart3 size={20} />, roles: [UserRole.ADMIN] }, 
    { path: '/settings', label: 'الإعدادات والأمان', icon: <Settings size={20} />, roles: [UserRole.ADMIN] },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside className="w-64 h-full glass-panel border-l border-white/50 z-50 flex flex-col transition-all">
      <div className="p-8 flex flex-col items-center justify-center border-b border-slate-200/50 relative overflow-hidden">
        <div className="w-16 h-16 bg-fas-500 rounded-2xl shadow-lg flex items-center justify-center text-white mb-3 z-10">
           <Hexagon size={36} />
        </div>
        <h1 className="text-xl font-bold text-slate-700 tracking-wider z-10">FAS</h1>
        <p className="text-xs text-slate-500 z-10">Architectural Solutions</p>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-fas-400/20 blur-3xl rounded-full"></div>
      </div>

      <nav className="flex-1 p-4 space-y-3 overflow-y-auto">
        {menuItems.filter(item => item.roles.includes(user.role)).map((item) => (
          <Link to={item.path} key={item.path} className="relative block">
            <div className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 ${
              activePath === item.path 
                ? 'bg-fas-500 text-white shadow-[4px_4px_10px_rgba(20,184,166,0.4)]' 
                : 'text-slate-600 hover:bg-white/50'
            }`}>
              {item.icon}
              <span className="font-semibold text-sm">{item.label}</span>
              
              {item.badge && item.badge > 0 && (
                <span className="absolute left-3 top-1/2 -translate-y-1/2 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm animate-pulse">
                  {item.badge}
                </span>
              )}
            </div>
          </Link>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-200/50">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-slate-300 to-slate-100 shadow-inner flex items-center justify-center font-bold text-slate-600 border border-white">
            {user.username.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-slate-700 truncate">{user.fullName}</p>
            <p className="text-xs text-slate-500 capitalize">{user.role.toLowerCase()}</p>
          </div>
        </div>
        <button 
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-2 rounded-xl text-red-500 hover:bg-red-50 transition-colors text-sm font-bold"
        >
          <LogOut size={16} />
          تسجيل خروج
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
