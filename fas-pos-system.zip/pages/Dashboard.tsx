import React, { useEffect, useState } from 'react';
import { GlassCard } from '../components/GlassCard';
import { dbService } from '../services/dbService';
import { Invoice, Product } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { DollarSign, Package, TrendingUp, Users } from 'lucide-react';

const StatCard = ({ title, value, icon, color }: any) => (
  <div className="bg-[#eef0f4] p-4 rounded-2xl shadow-neu-flat flex items-center justify-between">
    <div>
      <p className="text-slate-500 text-sm mb-1 font-semibold">{title}</p>
      <h3 className="text-2xl font-bold text-slate-700">{value}</h3>
    </div>
    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg ${color}`}>
      {icon}
    </div>
  </div>
);

const Dashboard = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    const inv = dbService.getInvoices();
    setInvoices(inv);
    setProducts(dbService.getProducts());

    // Process chart data (Last 7 days sales)
    const last7Days = [...Array(7)].map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    const data = last7Days.map(date => {
      const dayTotal = inv
        .filter(i => i.date.startsWith(date))
        .reduce((acc, curr) => acc + curr.total, 0);
      return { name: date.slice(5), sales: dayTotal };
    });
    setChartData(data);
  }, []);

  const totalRevenue = invoices.reduce((acc, i) => acc + i.total, 0);
  const totalTransactions = invoices.length;
  const lowStockCount = products.filter(p => p.stock <= p.minStockAlert).length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-700">لوحة المعلومات</h2>
        <p className="text-slate-500 text-sm">{new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard delay={0.1}>
          <StatCard 
            title="إجمالي المبيعات" 
            value={`${totalRevenue.toLocaleString()} ج.م`} 
            icon={<DollarSign size={24} />} 
            color="bg-fas-500" 
          />
        </GlassCard>
        <GlassCard delay={0.2}>
          <StatCard 
            title="عدد الفواتير" 
            value={totalTransactions} 
            icon={<TrendingUp size={24} />} 
            color="bg-blue-500" 
          />
        </GlassCard>
        <GlassCard delay={0.3}>
          <StatCard 
            title="تنبيهات المخزون" 
            value={lowStockCount} 
            icon={<Package size={24} />} 
            color="bg-orange-500" 
          />
        </GlassCard>
        <GlassCard delay={0.4}>
          <StatCard 
            title="إجمالي المنتجات" 
            value={products.length} 
            icon={<Users size={24} />} 
            color="bg-purple-500" 
          />
        </GlassCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Chart */}
        <GlassCard className="lg:col-span-2" delay={0.5}>
          <h3 className="text-lg font-bold text-slate-700 mb-4">أداء المبيعات (آخر 7 أيام)</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#cbd5e1" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" axisLine={false} tickLine={false} />
                <YAxis stroke="#64748b" axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                />
                <Area type="monotone" dataKey="sales" stroke="#14b8a6" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Recent Invoices */}
        <GlassCard delay={0.6}>
          <h3 className="text-lg font-bold text-slate-700 mb-4">أحدث العمليات</h3>
          <div className="space-y-3">
            {invoices.slice(-5).reverse().map((inv) => (
              <div key={inv.id} className="flex items-center justify-between p-3 bg-white/40 rounded-xl border border-white/60">
                <div>
                  <p className="font-bold text-slate-700 text-sm">{inv.invoiceNumber}</p>
                  <p className="text-xs text-slate-500">{new Date(inv.date).toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
                <span className="font-bold text-fas-600">{inv.total.toLocaleString()} ج.م</span>
              </div>
            ))}
            {invoices.length === 0 && <p className="text-center text-slate-400 text-sm py-4">لا توجد عمليات بعد</p>}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export default Dashboard;
