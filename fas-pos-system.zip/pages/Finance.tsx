
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/dbService';
import { Employee, Project, PayrollRecord, Expense } from '../types';
import { GlassCard } from '../components/GlassCard';
import { NeuButton } from '../components/NeuButton';
import { Plus, Users, DollarSign, Briefcase, Upload, Save, User, X, TrendingUp, ArrowDownRight, ArrowUpRight, Trash2, Edit, CheckCircle, Wallet, FileText, Receipt, Calendar } from 'lucide-react';
import jsPDF from 'jspdf';

const Finance = () => {
  const [activeTab, setActiveTab] = useState<'STAFF' | 'PAYROLL' | 'PROJECTS'>('STAFF');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payrollHistory, setPayrollHistory] = useState<PayrollRecord[]>([]);
  
  // Modals State
  const [showEmpModal, setShowEmpModal] = useState(false);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [showProjDetailsModal, setShowProjDetailsModal] = useState<string | null>(null);

  // Forms State
  const [empForm, setEmpForm] = useState<Partial<Employee>>({ name: '', role: '', baseSalary: 0, phone: '', loanBalance: 0, photo: '' });
  const [projForm, setProjForm] = useState<Partial<Project>>({ name: '', clientName: '', budget: 0, status: 'ACTIVE', totalIncome: 0 });
  const [loanForm, setLoanForm] = useState<{ empId: string, empName: string, amount: number }>({ empId: '', empName: '', amount: 0 });
  
  // Offer Letter State
  const [offerForm, setOfferForm] = useState({ empId: '', empName: '', role: '', salary: 0, startDate: new Date().toISOString().split('T')[0] });
  
  // Project Detail Expense Form
  const [newProjExpense, setNewProjExpense] = useState({ title: '', amount: 0 });

  // Payroll State
  const [payrollMonth, setPayrollMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
  const [payrollData, setPayrollData] = useState<Record<string, { absent: number, bonus: number, transport: number, loanPay: number }>>({});

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setEmployees(dbService.getEmployees());
    setProjects(dbService.getProjects());
    setExpenses(dbService.getExpenses());
    setPayrollHistory(dbService.getPayroll());
  };

  // --- Employee Logic ---
  const handleEmpSave = (e: React.FormEvent) => {
    e.preventDefault();
    const newEmp: Employee = {
      id: empForm.id || Date.now().toString(),
      name: empForm.name!,
      role: empForm.role!,
      phone: empForm.phone || '',
      baseSalary: Number(empForm.baseSalary),
      joinDate: empForm.joinDate || new Date().toISOString(),
      loanBalance: Number(empForm.loanBalance) || 0,
      photo: empForm.photo
    };
    dbService.saveEmployee(newEmp);
    setShowEmpModal(false);
    setEmpForm({});
    refreshData();
    alert('تم حفظ بيانات الموظف بنجاح');
  };

  const handleEditEmp = (emp: Employee) => {
    setEmpForm(emp);
    setShowEmpModal(true);
  };

  const handleDeleteEmp = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا الموظف نهائياً؟ سيتم حذف سجلاته.')) {
        dbService.deleteEmployee(id);
        refreshData();
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setEmpForm({ ...empForm, photo: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  // --- Offer Letter Logic ---
  const openOfferModal = (emp: Employee) => {
    setOfferForm({ 
        empId: emp.id, 
        empName: emp.name, 
        role: emp.role, 
        salary: emp.baseSalary, 
        startDate: new Date().toISOString().split('T')[0] 
    });
    setShowOfferModal(true);
  };

  const generateOfferLetter = () => {
    const doc = new jsPDF();
    const settings = dbService.getSettings();

    // Add Logo if available
    if(settings.companyLogo) {
        try {
            doc.addImage(settings.companyLogo, 'PNG', 150, 10, 40, 40);
        } catch(e) { console.log('Logo error'); }
    }

    doc.setFontSize(22);
    doc.text("Job Offer Letter", 105, 60, { align: "center" });

    doc.setFontSize(12);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 80);
    doc.text(`To: ${offerForm.empName}`, 20, 90);

    doc.text(`Dear ${offerForm.empName},`, 20, 110);
    
    const lines = [
        `We are pleased to offer you the position of ${offerForm.role} at ${settings.companyName}.`,
        `Your starting date will be ${offerForm.startDate}.`,
        ``,
        `Compensation Package:`,
        `- Base Salary: ${offerForm.salary} ${settings.currency} per month.`,
        `- Standard company benefits included.`,
        ``,
        `We are excited to have you join our team and look forward to your contribution.`,
        ``,
        `Sincerely,`,
        `HR Manager`,
        `${settings.companyName}`
    ];

    doc.text(lines, 20, 120);

    doc.line(20, 220, 80, 220);
    doc.text("Employee Signature", 20, 225);
    
    doc.line(130, 220, 190, 220);
    doc.text("Manager Signature", 130, 225);

    doc.save(`Offer_Letter_${offerForm.empName}.pdf`);
    setShowOfferModal(false);
  };

  // --- Loan Logic ---
  const openLoanModal = (emp: Employee) => {
    setLoanForm({ empId: emp.id, empName: emp.name, amount: 0 });
    setShowLoanModal(true);
  };

  const handleSubmitLoan = (e: React.FormEvent) => {
    e.preventDefault();
    if (loanForm.amount <= 0) {
        alert('يجب إدخال مبلغ صحيح');
        return;
    }
    dbService.addLoan(loanForm.empId, Number(loanForm.amount));
    refreshData();
    setShowLoanModal(false);
    alert(`تم إضافة سلفة بقيمة ${loanForm.amount} للموظف ${loanForm.empName}`);
  };

  // --- Project Logic ---
  const handleProjSave = (e: React.FormEvent) => {
    e.preventDefault();
    const newProj: Project = {
      id: projForm.id || Date.now().toString(),
      name: projForm.name!,
      clientName: projForm.clientName!,
      status: projForm.status as any,
      budget: Number(projForm.budget),
      totalIncome: Number(projForm.totalIncome) || 0,
      startDate: new Date().toISOString()
    };
    dbService.saveProject(newProj);
    setShowProjectModal(false);
    setProjForm({});
    refreshData();
  };

  const addProjectIncome = (id: string) => {
    const amount = prompt('أدخل قيمة الدفعة المستلمة:');
    if(amount) {
        dbService.addProjectIncome(id, Number(amount));
        refreshData();
    }
  };

  const addProjectExpense = (projId: string) => {
    if(!newProjExpense.title || newProjExpense.amount <= 0) return;
    
    const expense: Expense = {
        id: Date.now().toString(),
        title: newProjExpense.title,
        amount: Number(newProjExpense.amount),
        category: 'مشروع',
        date: new Date().toISOString(),
        projectId: projId,
        notes: 'Added from Project Manager'
    };
    dbService.addExpense(expense);
    setNewProjExpense({title: '', amount: 0});
    refreshData();
  };

  const getProjectExpenses = (projId: string) => {
    return expenses.filter(e => e.projectId === projId);
  };

  // --- Payroll Logic ---
  const calculateSalary = (emp: Employee) => {
    const data = payrollData[emp.id] || { absent: 0, bonus: 0, transport: 0, loanPay: 0 };
    const dailyRate = emp.baseSalary / 30;
    const deduction = dailyRate * data.absent;
    const net = emp.baseSalary - deduction - data.loanPay + data.bonus + data.transport;
    return { ...data, deduction, net };
  };

  const handlePayrollChange = (empId: string, field: string, value: number) => {
    setPayrollData(prev => ({
      ...prev,
      [empId]: { ...prev[empId] || { absent: 0, bonus: 0, transport: 0, loanPay: 0 }, [field]: value }
    }));
  };

  const isEmployeePaidThisMonth = (empId: string) => {
      return payrollHistory.some(record => record.employeeId === empId && record.month === payrollMonth);
  };

  const submitPayroll = (emp: Employee) => {
    if (isEmployeePaidThisMonth(emp.id)) {
        alert('تم صرف راتب هذا الشهر لهذا الموظف بالفعل.');
        return;
    }

    const calc = calculateSalary(emp);
    
    if(confirm(`تأكيد صرف راتب ${emp.name}؟\nالصافي: ${Math.round(calc.net)} ج.م`)) {
        const record: PayrollRecord = {
            id: Date.now().toString(),
            employeeId: emp.id,
            employeeName: emp.name,
            date: new Date().toISOString(),
            month: payrollMonth,
            baseSalary: emp.baseSalary,
            absentDays: calc.absent,
            deductionAmount: calc.deduction,
            loanDeduction: calc.loanPay,
            bonuses: calc.bonus,
            transportAllowance: calc.transport,
            netSalary: calc.net
        };
        
        try {
            dbService.savePayrollRecord(record);
            refreshData(); 
            handlePayrollChange(emp.id, 'absent', 0);
            handlePayrollChange(emp.id, 'bonus', 0);
            handlePayrollChange(emp.id, 'transport', 0);
            handlePayrollChange(emp.id, 'loanPay', 0);
            alert('تم تسجيل عملية الصرف بنجاح!');
        } catch (error) {
            alert('حدث خطأ أثناء الحفظ، يرجى المحاولة مرة أخرى.');
        }
    }
  };

  // --- Render ---

  const renderStaff = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {employees.map(emp => (
        <GlassCard key={emp.id} className="relative overflow-hidden group">
           <div className="absolute top-4 left-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
             <button onClick={() => handleEditEmp(emp)} className="p-2 bg-blue-100 text-blue-600 rounded-lg shadow hover:bg-blue-200">
               <Edit size={16} />
             </button>
             <button onClick={() => handleDeleteEmp(emp.id)} className="p-2 bg-red-100 text-red-600 rounded-lg shadow hover:bg-red-200">
               <Trash2 size={16} />
             </button>
           </div>

          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-2xl bg-slate-200 flex items-center justify-center overflow-hidden shadow-inner border-2 border-white">
              {emp.photo ? <img src={emp.photo} className="w-full h-full object-cover" /> : <User size={32} className="text-slate-400" />}
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-700">{emp.name}</h3>
              <span className="bg-fas-100 text-fas-600 text-xs px-2 py-1 rounded-lg font-bold">{emp.role}</span>
            </div>
          </div>
          <div className="space-y-2 text-sm text-slate-600">
            <div className="flex justify-between border-b border-slate-100 pb-1">
              <span>الراتب الأساسي:</span>
              <span className="font-bold">{emp.baseSalary} ج.م</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1">
              <span>رصيد السلف:</span>
              <span className="font-bold text-red-500">{emp.loanBalance} ج.م</span>
            </div>
            <div className="flex justify-between">
               <span>الهاتف:</span>
               <span>{emp.phone}</span>
            </div>
          </div>
          <div className="mt-4 pt-4 flex gap-2">
            <NeuButton className="flex-1 text-xs" onClick={() => openLoanModal(emp)} icon={<Wallet size={14} />}>سلفة</NeuButton>
            <NeuButton className="flex-1 text-xs bg-slate-200 hover:bg-slate-300" onClick={() => openOfferModal(emp)} icon={<FileText size={14} />}>عرض عمل</NeuButton>
          </div>
        </GlassCard>
      ))}
      <button onClick={() => { setEmpForm({}); setShowEmpModal(true); }} className="border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center text-slate-400 hover:bg-white/30 hover:border-fas-400 hover:text-fas-500 transition-all min-h-[220px]">
        <Plus size={32} className="mb-2" />
        <span className="font-bold">إضافة موظف</span>
      </button>
    </div>
  );

  const renderPayroll = () => (
    <div className="space-y-6">
      <GlassCard className="overflow-x-auto">
      <div className="mb-6 flex items-center justify-between bg-fas-50/50 p-4 rounded-xl border border-fas-100">
        <div className="flex items-center gap-4">
            <label className="font-bold text-slate-700 text-lg">شهر القبض:</label>
            <input 
                type="month" 
                value={payrollMonth} 
                onChange={e => setPayrollMonth(e.target.value)} 
                className="p-2 rounded-xl bg-white shadow-sm outline-none border border-slate-200 font-bold text-fas-600" 
            />
        </div>
        <div className="text-sm text-slate-500">
            يتم ترحيل الصافي تلقائياً إلى المصروفات
        </div>
      </div>

      <table className="w-full text-right text-sm">
        <thead className="bg-slate-100 text-slate-700 font-bold">
          <tr>
            <th className="p-4 rounded-r-xl">الموظف</th>
            <th className="p-4">الراتب</th>
            <th className="p-4">غياب</th>
            <th className="p-4">خصم سلف</th>
            <th className="p-4">بدل مشاوير</th>
            <th className="p-4">حوافز</th>
            <th className="p-4">الصافي</th>
            <th className="p-4 rounded-l-xl">الحالة / إجراء</th>
          </tr>
        </thead>
        <tbody className="text-slate-600">
          {employees.map(emp => {
            const isPaid = isEmployeePaidThisMonth(emp.id);
            const calc = calculateSalary(emp);
            
            return (
              <tr key={emp.id} className={`border-b border-slate-100 hover:bg-white/50 transition-colors ${isPaid ? 'bg-green-50/30' : ''}`}>
                <td className="p-4 font-bold flex items-center gap-2">
                    {isPaid && <CheckCircle size={16} className="text-green-500" />}
                    {emp.name}
                </td>
                <td className="p-4">{emp.baseSalary}</td>
                <td className="p-4">
                    <input type="number" className="w-16 p-2 rounded-lg border border-slate-200 text-center outline-none focus:border-fas-400" min="0" 
                           value={payrollData[emp.id]?.absent || 0} 
                           onChange={e => handlePayrollChange(emp.id, 'absent', Number(e.target.value))} 
                           disabled={isPaid}
                    />
                </td>
                <td className="p-4">
                    <div className="flex flex-col">
                        <input type="number" className="w-20 p-2 rounded-lg border border-slate-200 text-center outline-none focus:border-fas-400" min="0" max={emp.loanBalance}
                            value={payrollData[emp.id]?.loanPay || 0} 
                            onChange={e => handlePayrollChange(emp.id, 'loanPay', Number(e.target.value))} 
                            disabled={isPaid}
                        />
                        <span className="text-[10px] text-red-400 mt-1">عليه: {emp.loanBalance}</span>
                    </div>
                </td>
                <td className="p-4">
                    <input type="number" className="w-20 p-2 rounded-lg border border-slate-200 text-center outline-none focus:border-fas-400" min="0" 
                           value={payrollData[emp.id]?.transport || 0} 
                           onChange={e => handlePayrollChange(emp.id, 'transport', Number(e.target.value))} 
                           disabled={isPaid}
                    />
                </td>
                <td className="p-4">
                    <input type="number" className="w-20 p-2 rounded-lg border border-slate-200 text-center outline-none focus:border-fas-400" min="0" 
                           value={payrollData[emp.id]?.bonus || 0} 
                           onChange={e => handlePayrollChange(emp.id, 'bonus', Number(e.target.value))} 
                           disabled={isPaid}
                    />
                </td>
                <td className="p-4 font-bold text-fas-600 text-lg">{Math.round(calc.net)}</td>
                <td className="p-4">
                    {isPaid ? (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-green-100 text-green-700 font-bold text-xs">
                            <CheckCircle size={12} /> تم الصرف
                        </span>
                    ) : (
                        <button onClick={() => submitPayroll(emp)} className="bg-fas-500 text-white px-4 py-2 rounded-xl shadow-sm hover:bg-fas-600 hover:shadow-md transition-all text-xs font-bold">
                            تسجيل وصرف
                        </button>
                    )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      </GlassCard>

      {/* Payroll History Mini-View */}
      <div className="pt-4">
          <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2"><Calendar size={20}/> سجل الرواتب السابقة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {payrollHistory.slice(-6).reverse().map(rec => (
                  <div key={rec.id} className="bg-white/40 p-4 rounded-xl border border-white shadow-sm flex justify-between items-center">
                      <div>
                          <p className="font-bold text-slate-700">{rec.employeeName}</p>
                          <p className="text-xs text-slate-500">شهر: {rec.month}</p>
                      </div>
                      <div className="text-right">
                          <p className="font-bold text-fas-600">{rec.netSalary} ج.م</p>
                          <p className="text-xs text-slate-400">{new Date(rec.date).toLocaleDateString()}</p>
                      </div>
                  </div>
              ))}
          </div>
      </div>
    </div>
  );

  const renderProjects = () => (
    <div className="space-y-6">
       <div className="flex justify-end">
         <NeuButton variant="primary" icon={<Plus size={18}/>} onClick={() => { setProjForm({}); setShowProjectModal(true); }}>
            مشروع جديد
         </NeuButton>
       </div>
       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
         {projects.map(proj => {
            const projExp = getProjectExpenses(proj.id);
            const expensesAmount = projExp.reduce((acc, curr) => acc + curr.amount, 0);
            const profit = proj.totalIncome - expensesAmount;
            
            return (
             <GlassCard key={proj.id} className="relative flex flex-col">
               <div className="flex justify-between items-start mb-4">
                 <div>
                    <h3 className="text-xl font-bold text-slate-700">{proj.name}</h3>
                    <p className="text-sm text-slate-500">{proj.clientName}</p>
                 </div>
                 <span className={`px-3 py-1 rounded-full text-xs font-bold ${proj.status === 'ACTIVE' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'}`}>
                    {proj.status === 'ACTIVE' ? 'جاري العمل' : 'منتهي'}
                 </span>
               </div>
               
               <div className="grid grid-cols-3 gap-2 mb-4 bg-white/40 p-3 rounded-xl">
                  <div className="text-center">
                    <p className="text-xs text-slate-500 mb-1">الدخل</p>
                    <p className="font-bold text-green-600 flex items-center justify-center gap-1">
                        <ArrowDownRight size={14}/> {proj.totalIncome}
                    </p>
                  </div>
                  <div className="text-center border-x border-slate-200">
                    <p className="text-xs text-slate-500 mb-1">المصروف</p>
                    <p className="font-bold text-red-500 flex items-center justify-center gap-1">
                        <ArrowUpRight size={14}/> {expensesAmount}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-slate-500 mb-1">الربح</p>
                    <p className={`font-bold ${profit >= 0 ? 'text-fas-600' : 'text-red-600'}`}>{profit}</p>
                  </div>
               </div>
               
               <div className="mt-auto flex gap-2">
                  <NeuButton className="flex-1 text-xs" onClick={() => addProjectIncome(proj.id)}>تسجيل دفعة</NeuButton>
                  <NeuButton className="flex-1 text-xs text-slate-500 bg-slate-100 hover:bg-slate-200" onClick={() => setShowProjDetailsModal(proj.id)}>
                      التفاصيل والمصاريف
                  </NeuButton>
               </div>
             </GlassCard>
            );
         })}
       </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-700">الإدارة المالية والموارد البشرية</h2>
        <div className="bg-white/40 p-1 rounded-xl flex gap-1">
          <button onClick={() => setActiveTab('STAFF')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'STAFF' ? 'bg-white shadow-sm text-fas-600' : 'text-slate-500'}`}>
             الموظفين
          </button>
          <button onClick={() => setActiveTab('PAYROLL')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'PAYROLL' ? 'bg-white shadow-sm text-fas-600' : 'text-slate-500'}`}>
             الرواتب
          </button>
          <button onClick={() => setActiveTab('PROJECTS')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'PROJECTS' ? 'bg-white shadow-sm text-fas-600' : 'text-slate-500'}`}>
             المشاريع
          </button>
        </div>
      </div>

      {activeTab === 'STAFF' && renderStaff()}
      {activeTab === 'PAYROLL' && renderPayroll()}
      {activeTab === 'PROJECTS' && renderProjects()}

      {/* Employee Modal (Add/Edit) */}
      {showEmpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
          <GlassCard className="w-full max-w-lg !bg-[#eef0f4] relative">
            <button onClick={() => setShowEmpModal(false)} className="absolute top-4 left-4"><X size={20}/></button>
            <h3 className="font-bold text-lg mb-4">{empForm.id ? 'تعديل بيانات موظف' : 'إضافة موظف جديد'}</h3>
            <form onSubmit={handleEmpSave} className="space-y-4">
                <div className="flex items-center gap-4 justify-center">
                    <div className="w-24 h-24 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden relative cursor-pointer hover:opacity-80 transition-opacity border-2 border-white shadow-md">
                         {empForm.photo ? <img src={empForm.photo} className="w-full h-full object-cover"/> : <Upload className="text-slate-400"/>}
                         <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handlePhotoUpload}/>
                    </div>
                    <div className="text-xs text-slate-500">
                        <p>اضغط لرفع صورة</p>
                        <p>PNG, JPG</p>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <input required placeholder="الاسم بالكامل" className="p-3 rounded-xl outline-none shadow-inner bg-white" value={empForm.name} onChange={e=>setEmpForm({...empForm, name: e.target.value})}/>
                    <input required placeholder="المسمى الوظيفي" className="p-3 rounded-xl outline-none shadow-inner bg-white" value={empForm.role} onChange={e=>setEmpForm({...empForm, role: e.target.value})}/>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <input required type="number" placeholder="الراتب الأساسي" className="p-3 rounded-xl outline-none shadow-inner bg-white" value={empForm.baseSalary || ''} onChange={e=>setEmpForm({...empForm, baseSalary: Number(e.target.value)})}/>
                    <input placeholder="رقم الهاتف" className="p-3 rounded-xl outline-none shadow-inner bg-white" value={empForm.phone} onChange={e=>setEmpForm({...empForm, phone: e.target.value})}/>
                </div>
                <NeuButton variant="primary" type="submit" className="w-full">حفظ البيانات</NeuButton>
            </form>
          </GlassCard>
        </div>
      )}

      {/* Add Loan Modal */}
      {showLoanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
            <GlassCard className="w-full max-w-md !bg-[#eef0f4] relative">
                <button onClick={() => setShowLoanModal(false)} className="absolute top-4 left-4"><X size={20}/></button>
                <h3 className="font-bold text-lg mb-2 text-slate-700">إضافة سلفة مالية</h3>
                <p className="text-sm text-slate-500 mb-6">للموظف: <span className="font-bold text-fas-600">{loanForm.empName}</span></p>
                
                <form onSubmit={handleSubmitLoan} className="space-y-4">
                    <div>
                        <label className="block text-sm font-bold text-slate-600 mb-2">قيمة السلفة</label>
                        <input 
                            type="number" 
                            autoFocus
                            required
                            min="1"
                            className="w-full p-4 text-lg rounded-xl bg-white shadow-inner outline-none text-center font-bold" 
                            placeholder="0.00"
                            value={loanForm.amount || ''} 
                            onChange={e=>setLoanForm({...loanForm, amount: Number(e.target.value)})}
                        />
                    </div>
                    <div className="pt-2">
                        <NeuButton variant="primary" type="submit" className="w-full">تأكيد العملية</NeuButton>
                    </div>
                </form>
            </GlassCard>
        </div>
      )}

      {/* Project Modal */}
      {showProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
          <GlassCard className="w-full max-w-lg !bg-[#eef0f4] relative">
             <button onClick={() => setShowProjectModal(false)} className="absolute top-4 left-4"><X size={20}/></button>
             <h3 className="font-bold text-lg mb-4">إنشاء مشروع جديد</h3>
             <form onSubmit={handleProjSave} className="space-y-4">
                 <input required placeholder="اسم المشروع (مثال: فيلا التجمع)" className="w-full p-3 rounded-xl outline-none bg-white shadow-inner" value={projForm.name} onChange={e=>setProjForm({...projForm, name: e.target.value})}/>
                 <input required placeholder="اسم العميل" className="w-full p-3 rounded-xl outline-none bg-white shadow-inner" value={projForm.clientName} onChange={e=>setProjForm({...projForm, clientName: e.target.value})}/>
                 <div className="grid grid-cols-2 gap-3">
                    <input type="number" placeholder="الميزانية التقديرية" className="p-3 rounded-xl outline-none bg-white shadow-inner" value={projForm.budget || ''} onChange={e=>setProjForm({...projForm, budget: Number(e.target.value)})}/>
                    <select className="p-3 rounded-xl outline-none bg-white shadow-inner" value={projForm.status} onChange={e=>setProjForm({...projForm, status: e.target.value as any})}>
                        <option value="ACTIVE">جاري العمل</option>
                        <option value="PENDING">معلق</option>
                        <option value="COMPLETED">مكتمل</option>
                    </select>
                 </div>
                 <NeuButton variant="primary" type="submit" className="w-full">إنشاء</NeuButton>
             </form>
          </GlassCard>
        </div>
      )}
      
      {/* Offer Letter Modal */}
      {showOfferModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
            <GlassCard className="w-full max-w-md !bg-[#eef0f4] relative">
                <button onClick={() => setShowOfferModal(false)} className="absolute top-4 left-4"><X size={20}/></button>
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2"><FileText size={20}/> تجهيز عرض عمل</h3>
                
                <div className="space-y-4">
                    <div>
                        <label className="text-xs font-bold text-slate-500">الموظف</label>
                        <input disabled className="w-full p-2 rounded-lg bg-slate-200" value={offerForm.empName} />
                    </div>
                    <div>
                        <label className="text-xs font-bold text-slate-500">تاريخ البدء</label>
                        <input type="date" className="w-full p-2 rounded-lg bg-white" value={offerForm.startDate} onChange={e => setOfferForm({...offerForm, startDate: e.target.value})} />
                    </div>
                    <div>
                        <label className="text-xs font-bold text-slate-500">الراتب المقترح</label>
                        <input type="number" className="w-full p-2 rounded-lg bg-white" value={offerForm.salary} onChange={e => setOfferForm({...offerForm, salary: Number(e.target.value)})} />
                    </div>
                    <NeuButton variant="primary" className="w-full mt-4" onClick={generateOfferLetter}>توليد PDF وطباعة</NeuButton>
                </div>
            </GlassCard>
        </div>
      )}

      {/* Project Details Modal */}
      {showProjDetailsModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
             <GlassCard className="w-full max-w-2xl h-[600px] !bg-[#eef0f4] relative flex flex-col">
                <button onClick={() => setShowProjDetailsModal(null)} className="absolute top-4 left-4"><X size={20}/></button>
                
                {(() => {
                    const p = projects.find(x => x.id === showProjDetailsModal);
                    const pExp = getProjectExpenses(showProjDetailsModal!);
                    
                    return p ? (
                        <>
                           <h3 className="font-bold text-xl mb-1">{p.name}</h3>
                           <p className="text-sm text-slate-500 mb-4 border-b pb-4">تفاصيل المصروفات الخاصة بالمشروع</p>
                           
                           <div className="flex-1 overflow-y-auto space-y-2 mb-4">
                               {pExp.length === 0 ? <p className="text-center text-slate-400 mt-10">لا توجد مصاريف مسجلة لهذا المشروع</p> : 
                               pExp.map(ex => (
                                   <div key={ex.id} className="flex justify-between items-center bg-white p-3 rounded-xl shadow-sm">
                                       <div>
                                           <p className="font-bold text-slate-700">{ex.title}</p>
                                           <p className="text-xs text-slate-400">{new Date(ex.date).toLocaleDateString()}</p>
                                       </div>
                                       <span className="font-bold text-red-500">-{ex.amount}</span>
                                   </div>
                               ))}
                           </div>

                           <div className="bg-slate-200 p-4 rounded-xl">
                               <h4 className="font-bold text-sm text-slate-600 mb-2">إضافة مصروف جديد للمشروع</h4>
                               <div className="flex gap-2">
                                   <input placeholder="بند الصرف (مثال: أسمنت)" className="flex-[2] p-2 rounded-lg outline-none" value={newProjExpense.title} onChange={e => setNewProjExpense({...newProjExpense, title: e.target.value})} />
                                   <input type="number" placeholder="المبلغ" className="flex-1 p-2 rounded-lg outline-none" value={newProjExpense.amount || ''} onChange={e => setNewProjExpense({...newProjExpense, amount: Number(e.target.value)})} />
                                   <button onClick={() => addProjectExpense(p.id)} className="bg-fas-500 text-white px-4 rounded-lg font-bold shadow-sm hover:bg-fas-600">+</button>
                               </div>
                           </div>
                        </>
                    ) : null;
                })()}
             </GlassCard>
          </div>
      )}
    </div>
  );
};

export default Finance;
