
import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';
import { NeuButton } from '../components/NeuButton';
import { Hexagon, User, Lock, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(username, password)) {
      navigate('/');
    } else {
      setError('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#eef0f4] relative overflow-hidden">
       {/* Ambient Background */}
       <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-fas-400/20 rounded-full blur-[100px]" />
       <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-400/20 rounded-full blur-[100px]" />

       <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md p-8 glass-panel rounded-3xl relative z-10"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 bg-fas-500 rounded-2xl shadow-lg flex items-center justify-center text-white mb-4 transform rotate-3 hover:rotate-0 transition-transform">
            <Hexagon size={48} />
          </div>
          <h1 className="text-2xl font-bold text-slate-700">Fekrah Arch. Solutions</h1>
          <p className="text-slate-500 text-sm mt-1">تسجيل الدخول للنظام</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm flex items-center gap-2 border border-red-100">
              <AlertCircle size={16} /> {error}
            </div>
          )}

          <div className="relative">
            <div className="absolute right-4 top-3.5 text-slate-400">
              <User size={20} />
            </div>
            <input
              type="text"
              placeholder="اسم المستخدم (admin)"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-[#eef0f4] rounded-xl py-3 pr-12 pl-4 text-slate-700 outline-none shadow-[inset_2px_2px_5px_rgba(0,0,0,0.05),inset_-2px_-2px_5px_rgba(255,255,255,0.8)] focus:shadow-[inset_2px_2px_5px_rgba(20,184,166,0.1),inset_-2px_-2px_5px_rgba(255,255,255,0.8)] transition-all"
            />
          </div>

          <div className="relative">
            <div className="absolute right-4 top-3.5 text-slate-400">
              <Lock size={20} />
            </div>
            <input
              type="password"
              placeholder="كلمة المرور (password)"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#eef0f4] rounded-xl py-3 pr-12 pl-4 text-slate-700 outline-none shadow-[inset_2px_2px_5px_rgba(0,0,0,0.05),inset_-2px_-2px_5px_rgba(255,255,255,0.8)] focus:shadow-[inset_2px_2px_5px_rgba(20,184,166,0.1),inset_-2px_-2px_5px_rgba(255,255,255,0.8)] transition-all"
            />
          </div>

          <NeuButton type="button" variant="primary" className="w-full" onClick={handleSubmit}>
            دخول
          </NeuButton>
        </form>
       </motion.div>
    </div>
  );
};

export default Login;
