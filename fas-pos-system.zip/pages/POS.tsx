
import React, { useState, useEffect, useRef } from 'react';
import { dbService } from '../services/dbService';
import { Product, CartItem, AppSettings, User, Invoice } from '../types';
import { NeuButton } from '../components/NeuButton';
import { GlassCard } from '../components/GlassCard';
import { Search, Trash2, Plus, Minus, CreditCard, Printer, Save } from 'lucide-react';
import jsPDF from 'jspdf';

const POS = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState('');
  const [settings, setSettings] = useState<AppSettings>(dbService.getSettings());
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const prods = dbService.getProducts();
    setProducts(prods);
    setFilteredProducts(prods);
    setSettings(dbService.getSettings());
    
    // Focus barcode input
    if(barcodeInputRef.current) barcodeInputRef.current.focus();
  }, []);

  useEffect(() => {
    if (search.trim() === '') {
      setFilteredProducts(products);
    } else {
      setFilteredProducts(products.filter(p => 
        p.name.toLowerCase().includes(search.toLowerCase()) || 
        p.barcode.includes(search) ||
        p.category.toLowerCase().includes(search.toLowerCase())
      ));
    }
  }, [search, products]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const exists = prev.find(item => item.id === product.id);
      if (exists) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1, discount: 0 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const handleCheckout = (method: 'CASH' | 'CARD') => {
    if (cart.length === 0) return;

    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * settings.taxRate;
    const discount = 0; // Implement discount logic if needed
    const total = subtotal + tax - discount;

    const user = JSON.parse(localStorage.getItem('fas_session') || '{}') as User;

    const invoice: Invoice = {
      id: Date.now().toString(),
      invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString(),
      cashierId: user.id || 'unknown',
      cashierName: user.fullName || 'Cashier',
      items: cart,
      subtotal,
      tax,
      discount,
      total,
      paymentMethod: method
    };

    dbService.createInvoice(invoice);
    
    // Print Logic
    if(settings.printerType === 'THERMAL') {
        // In a real Electron app, this would send ESC/POS commands
        alert(`Printing Receipt #${invoice.invoiceNumber} on 80mm Thermal Printer...`);
        // We can also download PDF as a backup
        // generatePDF(invoice);
    } else {
        generatePDF(invoice);
    }

    setCart([]);
    alert('تمت العملية بنجاح!');
    // Refresh products to show updated stock
    setProducts(dbService.getProducts());
  };

  const generatePDF = (invoice: Invoice) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    const margin = 20;
    let y = margin;

    // --- 1. HEADER SECTION ---
    
    // Logo (Right aligned for LTR pdf, or strictly positioned)
    // We position logo top-right
    if (settings.companyLogo) {
      try {
        const isPng = settings.companyLogo.indexOf('image/png') > -1;
        const format = isPng ? 'PNG' : 'JPEG';
        // x, y, w, h
        doc.addImage(settings.companyLogo, format, pageWidth - margin - 30, margin - 5, 30, 30);
      } catch (e) {
        console.error("Error adding logo to PDF", e);
      }
    }

    // Company Info (Left aligned)
    doc.setFontSize(24);
    doc.setTextColor(44, 62, 80);
    doc.text(settings.companyName || 'FAS Solutions', margin, y + 5);
    
    y += 15;
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    if (settings.companyAddress) {
        const addressLines = doc.splitTextToSize(settings.companyAddress, 100);
        doc.text(addressLines, margin, y);
        y += (addressLines.length * 5);
    }
    if (settings.companyPhone) {
        doc.text(settings.companyPhone, margin, y);
    }

    // --- 2. INVOICE DETAILS ---
    y = Math.max(y + 15, 60); // Ensure we don't overlap logo
    
    doc.setFontSize(18);
    doc.setTextColor(20, 184, 166); // FAS Teal
    doc.text("INVOICE", margin, y);
    
    y += 10;
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    
    doc.text(`Invoice #: ${invoice.invoiceNumber}`, margin, y);
    doc.text(`Date: ${new Date(invoice.date).toLocaleString('en-GB')}`, margin, y + 6);
    doc.text(`Cashier: ${invoice.cashierName}`, margin, y + 12);
    doc.text(`Payment: ${invoice.paymentMethod}`, margin, y + 18);

    // --- 3. ITEMS TABLE ---
    y += 30;
    
    // Table Header
    doc.setFillColor(241, 245, 249); // Light gray
    doc.rect(margin, y - 8, pageWidth - (margin * 2), 10, 'F');
    doc.setFont("helvetica", "bold");
    doc.setTextColor(71, 85, 105);
    
    doc.text("Item", margin + 5, y);
    doc.text("Qty", margin + 100, y);
    doc.text("Price", margin + 125, y);
    doc.text("Total", margin + 155, y);

    // Table Rows
    y += 10;
    doc.setFont("helvetica", "normal");
    doc.setTextColor(0, 0, 0);
    
    invoice.items.forEach((item) => {
        // Truncate long names
        const name = item.name.length > 40 ? item.name.substring(0, 37) + '...' : item.name;
        doc.text(name, margin + 5, y);
        doc.text(item.quantity.toString(), margin + 100, y);
        doc.text(item.price.toFixed(2), margin + 125, y);
        doc.text((item.price * item.quantity).toFixed(2), margin + 155, y);
        y += 8;
    });

    // --- 4. TOTALS ---
    y += 5;
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, pageWidth - margin, y);
    y += 10;

    const totalsX = pageWidth - margin - 60;
    
    doc.setFontSize(10);
    doc.text("Subtotal:", totalsX, y);
    doc.text(invoice.subtotal.toFixed(2), pageWidth - margin, y, { align: 'right' });
    y += 6;
    
    doc.text(`Tax (${(settings.taxRate * 100).toFixed(0)}%):`, totalsX, y);
    doc.text(invoice.tax.toFixed(2), pageWidth - margin, y, { align: 'right' });
    y += 8;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(20, 184, 166); // Teal
    doc.text("TOTAL:", totalsX, y);
    doc.text(`${invoice.total.toFixed(2)} ${settings.currency}`, pageWidth - margin, y, { align: 'right' });

    // Footer
    doc.setTextColor(148, 163, 184);
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text("Thank you for your business!", pageWidth / 2, 280, { align: 'center' });

    doc.save(`Invoice_${invoice.invoiceNumber}.pdf`);
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * settings.taxRate;
  const total = subtotal + tax;

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] gap-6">
      {/* Products Grid */}
      <div className="flex-1 flex flex-col gap-4">
        <GlassCard className="flex items-center gap-4 py-3">
          <Search className="text-slate-400" />
          <input 
            ref={barcodeInputRef}
            className="flex-1 bg-transparent outline-none text-slate-700 placeholder-slate-400 font-semibold"
            placeholder="ابحث عن منتج أو امسح الباركود..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            autoFocus
          />
        </GlassCard>

        <div className="flex-1 overflow-y-auto pr-2">
           <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map(product => (
              <div 
                key={product.id}
                onClick={() => addToCart(product)}
                className="bg-white/50 p-4 rounded-xl shadow-sm border border-white/60 cursor-pointer hover:scale-[1.02] transition-transform active:scale-95 select-none group"
              >
                <div className="h-24 bg-slate-200 rounded-lg mb-3 flex items-center justify-center text-slate-400 font-bold text-xs relative overflow-hidden">
                  {product.imageUrl ? <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" /> : 'NO IMAGE'}
                  <div className="absolute top-2 right-2 bg-fas-500 text-white text-xs px-2 py-1 rounded-md shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                    Stock: {product.stock}
                  </div>
                </div>
                <h4 className="font-bold text-slate-700 text-sm truncate">{product.name}</h4>
                <p className="text-fas-600 font-bold mt-1">{product.price} {settings.currency}</p>
              </div>
            ))}
           </div>
        </div>
      </div>

      {/* Cart Sidebar */}
      <GlassCard className="w-full lg:w-[400px] flex flex-col !p-0 overflow-hidden border-slate-300">
        <div className="p-5 bg-white/30 border-b border-white/50">
          <h3 className="font-bold text-slate-700 flex items-center gap-2">
            <CreditCard size={20}/>
            سلة المشتريات
          </h3>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
             <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60">
               <CreditCard size={48} className="mb-2" />
               <p>السلة فارغة</p>
             </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="bg-[#eef0f4] p-3 rounded-xl flex items-center gap-3 shadow-inner">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-slate-700 truncate">{item.name}</p>
                  <p className="text-xs text-slate-500">{(item.price * item.quantity).toFixed(2)} {settings.currency}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQuantity(item.id, -1)} className="w-7 h-7 rounded-lg bg-white shadow-sm flex items-center justify-center hover:bg-slate-50">
                    <Minus size={14} />
                  </button>
                  <span className="font-bold text-sm w-4 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} className="w-7 h-7 rounded-lg bg-white shadow-sm flex items-center justify-center hover:bg-slate-50">
                    <Plus size={14} />
                  </button>
                </div>
                <button onClick={() => removeFromCart(item.id)} className="text-red-400 hover:text-red-600 p-1">
                  <Trash2 size={18} />
                </button>
              </div>
            ))
          )}
        </div>

        <div className="p-6 bg-white/40 backdrop-blur-xl border-t border-white/50">
          <div className="space-y-2 mb-4 text-sm">
            <div className="flex justify-between text-slate-600">
              <span>المجموع الفرعي</span>
              <span>{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>الضريبة ({(settings.taxRate * 100).toFixed(0)}%)</span>
              <span>{tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-800 font-bold text-xl mt-2 pt-2 border-t border-slate-300">
              <span>الإجمالي</span>
              <span>{total.toFixed(2)} {settings.currency}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
             <NeuButton variant="primary" onClick={() => handleCheckout('CASH')} disabled={cart.length===0}>
                كاش
             </NeuButton>
             <NeuButton onClick={() => handleCheckout('CARD')} disabled={cart.length===0}>
                فيزا
             </NeuButton>
          </div>
        </div>
      </GlassCard>
    </div>
  );
};

export default POS;
