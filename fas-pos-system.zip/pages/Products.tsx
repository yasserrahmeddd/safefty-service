import React, { useState, useEffect } from 'react';
import { dbService } from '../services/dbService';
import { Product } from '../types';
import { GlassCard } from '../components/GlassCard';
import { NeuButton } from '../components/NeuButton';
import { Plus, Edit, Trash, Save, X } from 'lucide-react';

const Products = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const initialForm = { name: '', category: '', price: 0, cost: 0, stock: 0, minStockAlert: 5, barcode: '' };
  const [formData, setFormData] = useState(initialForm);

  useEffect(() => {
    setProducts(dbService.getProducts());
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const productToSave: Product = {
      id: editingProduct ? editingProduct.id : '', // Service handles new ID
      ...formData
    };
    
    dbService.saveProduct(productToSave);
    setProducts(dbService.getProducts());
    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if(confirm('هل أنت متأكد من الحذف؟')) {
      dbService.deleteProduct(id);
      setProducts(dbService.getProducts());
    }
  };

  const openEdit = (p: Product) => {
    setEditingProduct(p);
    setFormData({ 
      name: p.name, 
      category: p.category, 
      price: p.price, 
      cost: p.cost, 
      stock: p.stock, 
      minStockAlert: p.minStockAlert, 
      barcode: p.barcode 
    });
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingProduct(null);
    setFormData(initialForm);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-700">إدارة المخزون والمنتجات</h2>
        <NeuButton variant="primary" icon={<Plus size={18}/>} onClick={() => setIsModalOpen(true)}>
          إضافة منتج
        </NeuButton>
      </div>

      <GlassCard className="overflow-hidden !p-0">
        <table className="w-full text-right">
          <thead className="bg-white/50 text-slate-600 font-bold text-sm border-b border-slate-200">
            <tr>
              <th className="p-4">الاسم</th>
              <th className="p-4">القسم</th>
              <th className="p-4">السعر</th>
              <th className="p-4">المخزون</th>
              <th className="p-4">إجراءات</th>
            </tr>
          </thead>
          <tbody className="text-slate-700 text-sm">
            {products.map((p, idx) => (
              <tr key={p.id} className={`border-b border-slate-100/50 hover:bg-white/30 ${idx % 2 === 0 ? 'bg-white/10' : ''}`}>
                <td className="p-4 font-semibold">{p.name}</td>
                <td className="p-4 bg-slate-100/30 rounded-lg inline-block m-2 text-xs px-2 py-1">{p.category}</td>
                <td className="p-4">{p.price}</td>
                <td className={`p-4 font-bold ${p.stock <= p.minStockAlert ? 'text-red-500' : 'text-green-600'}`}>
                  {p.stock}
                </td>
                <td className="p-4 flex gap-2">
                  <button onClick={() => openEdit(p)} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
                    <Edit size={16} />
                  </button>
                  <button onClick={() => handleDelete(p.id)} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100">
                    <Trash size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </GlassCard>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
          <GlassCard className="w-full max-w-lg relative !bg-[#eef0f4]">
            <button onClick={handleCloseModal} className="absolute top-4 left-4 text-slate-400 hover:text-slate-600">
              <X size={24} />
            </button>
            <h3 className="text-xl font-bold mb-6 text-slate-700">{editingProduct ? 'تعديل منتج' : 'إضافة منتج جديد'}</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">اسم المنتج</label>
                    <input required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">القسم</label>
                    <input required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">سعر البيع</label>
                    <input type="number" required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})} />
                </div>
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">التكلفة</label>
                    <input type="number" required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.cost} onChange={e => setFormData({...formData, cost: Number(e.target.value)})} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">المخزون الحالي</label>
                    <input type="number" required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.stock} onChange={e => setFormData({...formData, stock: Number(e.target.value)})} />
                </div>
                 <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">حد الخطر</label>
                    <input type="number" required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.minStockAlert} onChange={e => setFormData({...formData, minStockAlert: Number(e.target.value)})} />
                </div>
              </div>

              <div>
                 <label className="text-xs font-bold text-slate-500 block mb-1">الباركود</label>
                 <input required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.barcode} onChange={e => setFormData({...formData, barcode: e.target.value})} />
              </div>

              <div className="pt-4 flex gap-3">
                <NeuButton type="submit" variant="primary" className="flex-1">حفظ</NeuButton>
                <NeuButton type="button" onClick={handleCloseModal} className="flex-1">إلغاء</NeuButton>
              </div>
            </form>
          </GlassCard>
        </div>
      )}
    </div>
  );
};

export default Products;
