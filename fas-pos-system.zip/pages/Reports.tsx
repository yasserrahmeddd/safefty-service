import React, { useEffect, useState } from 'react';
import { dbService } from '../services/dbService';
import { Invoice } from '../types';
import { GlassCard } from '../components/GlassCard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { FileText } from 'lucide-react';

const Reports = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    const allInvoices = dbService.getInvoices();
    setInvoices(allInvoices);

    // Group by Cashier for this report example
    const cashierStats: Record<string, number> = {};
    allInvoices.forEach(inv => {
      cashierStats[inv.cashierName] = (cashierStats[inv.cashierName] || 0) + inv.total;
    });

    setChartData(Object.keys(cashierStats).map(name => ({
      name,
      total: cashierStats[name]
    })));
  }, []);

  return (
    <div className="space-y-6">
       <h2 className="text-2xl font-bold text-slate-700">التقارير المالية</h2>

       <GlassCard>
         <h3 className="font-bold text-slate-600 mb-4">المبيعات حسب المستخدم (كاشير)</h3>
         <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip cursor={{fill: 'rgba(255,255,255,0.2)'}} contentStyle={{borderRadius: '12px'}} />
                <Legend />
                <Bar dataKey="total" name="إجمالي المبيعات" fill="#14b8a6" radius={[10, 10, 0, 0]} barSize={50} />
              </BarChart>
            </ResponsiveContainer>
         </div>
       </GlassCard>

       <GlassCard>
         <h3 className="font-bold text-slate-600 mb-4">سجل الفواتير الكامل</h3>
         <div className="overflow-x-auto">
           <table className="w-full text-right text-sm">
             <thead className="bg-white/30 text-slate-600">
               <tr>
                 <th className="p-3 rounded-r-lg">رقم الفاتورة</th>
                 <th className="p-3">التاريخ</th>
                 <th className="p-3">الكاشير</th>
                 <th className="p-3">الدفع</th>
                 <th className="p-3 rounded-l-lg">الإجمالي</th>
               </tr>
             </thead>
             <tbody>
               {invoices.map((inv, i) => (
                 <tr key={inv.id} className="border-b border-slate-100 hover:bg-white/40">
                   <td className="p-3 font-mono">{inv.invoiceNumber}</td>
                   <td className="p-3">{new Date(inv.date).toLocaleDateString()}</td>
                   <td className="p-3">{inv.cashierName}</td>
                   <td className="p-3">
                     <span className={`px-2 py-1 rounded text-xs font-bold ${inv.paymentMethod === 'CASH' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                       {inv.paymentMethod}
                     </span>
                   </td>
                   <td className="p-3 font-bold">{inv.total.toFixed(2)}</td>
                 </tr>
               ))}
             </tbody>
           </table>
         </div>
       </GlassCard>
    </div>
  );
};

export default Reports;
