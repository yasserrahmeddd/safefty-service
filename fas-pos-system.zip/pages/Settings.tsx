
import React, { useEffect, useState, useContext } from 'react';
import { dbService } from '../services/dbService';
import { AppSettings } from '../types';
import { GlassCard } from '../components/GlassCard';
import { NeuButton } from '../components/NeuButton';
import { Save, Upload, Image as ImageIcon, Trash2, Shield, Lock, User as UserIcon, CheckCircle, Database, Download, RefreshCcw, AlertTriangle } from 'lucide-react';
import { AuthContext } from '../contexts/AuthContext';

const Settings = () => {
  const { user, logout } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState<'GENERAL' | 'SECURITY' | 'SYSTEM'>('GENERAL');
  
  // General Settings State
  const [settings, setSettings] = useState<AppSettings>({
    currency: 'EGP',
    taxRate: 0.14,
    companyName: '',
    companyAddress: '',
    companyPhone: '',
    printerType: 'THERMAL'
  });

  // Security State
  const [secForm, setSecForm] = useState({
    username: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    setSettings(dbService.getSettings());
    if(user) {
        setSecForm(prev => ({...prev, username: user.username}));
    }
  }, [user]);

  // --- General Logic ---
  const handleSaveSettings = () => {
    dbService.saveSettings(settings);
    // Show simple toast or alert
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 left-1/2 -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-xl shadow-lg z-50 animate-bounce font-bold';
    notification.innerText = 'تم حفظ الإعدادات بنجاح';
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500 * 1024) {
        alert("حجم الصورة كبير جداً. يرجى اختيار صورة أقل من 500 كيلوبايت.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setSettings({ ...settings, companyLogo: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  // --- Security Logic ---
  const validatePassword = (pwd: string) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    return regex.test(pwd);
  };

  const handleUpdateSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const currentUserData = dbService.getCurrentUser(user.id);
    if (!currentUserData || currentUserData.passwordHash !== secForm.currentPassword) {
        alert('كلمة المرور الحالية غير صحيحة');
        return;
    }

    if (!validatePassword(secForm.newPassword)) {
        alert('كلمة المرور الجديدة ضعيفة. يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف كبير وحرف صغير ورقم.');
        return;
    }

    if (secForm.newPassword !== secForm.confirmPassword) {
        alert('كلمة المرور الجديدة غير متطابقة.');
        return;
    }

    dbService.updateUserCredentials(user.id, secForm.username, secForm.newPassword);
    alert('تم تحديث بيانات الدخول بنجاح. يرجى تسجيل الدخول مرة أخرى.');
    logout();
  };

  // --- System Logic ---
  const handleBackup = () => {
    const data: Record<string, any> = {};
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('fas_')) {
            data[key] = JSON.parse(localStorage.getItem(key) || 'null');
        }
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FAS_Backup_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
  };

  const handleFactoryReset = () => {
    if(confirm('تحذير خطير: هل أنت متأكد من حذف جميع بيانات النظام؟ (المنتجات، الفواتير، الموظفين...)؟ لا يمكن التراجع عن هذه الخطوة.')) {
       if(prompt('للتأكيد اكتب: حذف الكل') === 'حذف الكل') {
           localStorage.clear();
           window.location.reload();
       }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-slate-700">إعدادات النظام</h2>
        <div className="flex gap-2 bg-white/50 p-1 rounded-xl overflow-x-auto max-w-full">
            <button onClick={() => setActiveTab('GENERAL')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'GENERAL' ? 'bg-fas-500 text-white shadow-md' : 'text-slate-500 hover:bg-white/50'}`}>
                <Save size={16} /> عام
            </button>
            <button onClick={() => setActiveTab('SECURITY')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'SECURITY' ? 'bg-fas-500 text-white shadow-md' : 'text-slate-500 hover:bg-white/50'}`}>
                <Shield size={16} /> الأمان
            </button>
            <button onClick={() => setActiveTab('SYSTEM')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'SYSTEM' ? 'bg-fas-500 text-white shadow-md' : 'text-slate-500 hover:bg-white/50'}`}>
                <Database size={16} /> النسخ والصيانة
            </button>
        </div>
      </div>
      
      {activeTab === 'GENERAL' ? (
        <GlassCard className="space-y-6">
            <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="w-full md:w-auto flex flex-col items-center gap-4">
                    <label className="text-sm font-bold text-slate-600">شعار الشركة</label>
                    <div className="relative group w-32 h-32 rounded-2xl border-2 border-dashed border-slate-300 overflow-hidden flex items-center justify-center bg-white shadow-sm">
                        {settings.companyLogo ? (
                            <>
                            <img src={settings.companyLogo} alt="Company Logo" className="w-full h-full object-contain p-2" />
                            <button onClick={() => setSettings({...settings, companyLogo: undefined})} className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-all backdrop-blur-sm">
                                <Trash2 size={24} />
                            </button>
                            </>
                        ) : (
                            <ImageIcon size={32} className="text-slate-300" />
                        )}
                    </div>
                    <input type="file" accept="image/*" id="logo-upload" className="hidden" onChange={handleLogoUpload} />
                    <label htmlFor="logo-upload" className="cursor-pointer px-4 py-2 bg-fas-50 text-fas-600 border border-fas-200 rounded-lg shadow-sm font-bold text-xs hover:bg-fas-100 transition-all flex items-center gap-2">
                        <Upload size={14} />
                        رفع شعار
                    </label>
                </div>

                <div className="flex-1 w-full space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-bold text-slate-600 mb-2">اسم الشركة</label>
                            <input className="w-full p-3 rounded-xl bg-[#eef0f4] shadow-inner outline-none focus:ring-2 ring-fas-400/50 transition-all" value={settings.companyName} onChange={(e) => setSettings({...settings, companyName: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-600 mb-2">العملة</label>
                            <input className="w-full p-3 rounded-xl bg-[#eef0f4] shadow-inner outline-none transition-all" value={settings.currency} onChange={(e) => setSettings({...settings, currency: e.target.value})} />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-bold text-slate-600 mb-2">نسبة الضريبة (مثال 0.14)</label>
                            <input type="number" step="0.01" className="w-full p-3 rounded-xl bg-[#eef0f4] shadow-inner outline-none transition-all" value={settings.taxRate} onChange={(e) => setSettings({...settings, taxRate: parseFloat(e.target.value)})} />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-600 mb-2">نوع الطابعة</label>
                            <select className="w-full p-3 rounded-xl bg-[#eef0f4] shadow-inner outline-none transition-all cursor-pointer" value={settings.printerType} onChange={(e) => setSettings({...settings, printerType: e.target.value as any})}>
                                <option value="THERMAL">طابعة حرارية (80mm)</option>
                                <option value="A4">طابعة A4 عادية</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <hr className="border-slate-200/50" />

            <div>
            <label className="block text-sm font-bold text-slate-600 mb-2">بيانات التواصل (تظهر في الفاتورة)</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input placeholder="العنوان التفصيلي" className="w-full p-3 rounded-xl bg-[#eef0f4] shadow-inner outline-none transition-all" value={settings.companyAddress} onChange={(e) => setSettings({...settings, companyAddress: e.target.value})} />
                <input placeholder="رقم الهاتف / الموبايل" className="w-full p-3 rounded-xl bg-[#eef0f4] shadow-inner outline-none transition-all" value={settings.companyPhone} onChange={(e) => setSettings({...settings, companyPhone: e.target.value})} />
            </div>
            </div>

            <div className="pt-2 flex justify-end">
                <NeuButton variant="primary" onClick={handleSaveSettings} icon={<Save size={18} />}>
                    حفظ التغييرات
                </NeuButton>
            </div>
        </GlassCard>
      ) : activeTab === 'SECURITY' ? (
        <GlassCard className="space-y-8">
            <div className="bg-yellow-50 border border-yellow-100 p-4 rounded-xl flex items-start gap-3">
                <Lock className="text-yellow-600 shrink-0 mt-1" size={20} />
                <div>
                    <h4 className="font-bold text-yellow-800 text-sm">تغيير بيانات الدخول</h4>
                    <p className="text-xs text-yellow-600 mt-1">
                        يجب استخدام كلمة مرور قوية تحتوي على 8 أحرف على الأقل، وحرف كبير، وحرف صغير، ورقم واحد على الأقل.
                    </p>
                </div>
            </div>

            <form onSubmit={handleUpdateSecurity} className="space-y-5 max-w-lg mx-auto">
                <div>
                    <label className="block text-sm font-bold text-slate-600 mb-2">اسم المستخدم</label>
                    <div className="relative">
                        <UserIcon size={18} className="absolute top-3.5 right-4 text-slate-400" />
                        <input required type="text" className="w-full p-3 pr-12 rounded-xl bg-[#eef0f4] shadow-inner outline-none" value={secForm.username} onChange={e => setSecForm({...secForm, username: e.target.value})} />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-bold text-slate-600 mb-2">كلمة المرور الحالية</label>
                    <div className="relative">
                        <Lock size={18} className="absolute top-3.5 right-4 text-slate-400" />
                        <input required type="password" placeholder="********" className="w-full p-3 pr-12 rounded-xl bg-[#eef0f4] shadow-inner outline-none" value={secForm.currentPassword} onChange={e => setSecForm({...secForm, currentPassword: e.target.value})} />
                    </div>
                </div>

                <hr className="border-slate-200" />

                <div>
                    <label className="block text-sm font-bold text-slate-600 mb-2">كلمة المرور الجديدة</label>
                    <div className="relative">
                        <Lock size={18} className="absolute top-3.5 right-4 text-slate-400" />
                        <input required type="password" className="w-full p-3 pr-12 rounded-xl bg-[#eef0f4] shadow-inner outline-none border border-transparent focus:border-fas-400 transition-colors" value={secForm.newPassword} onChange={e => setSecForm({...secForm, newPassword: e.target.value})} />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-bold text-slate-600 mb-2">تأكيد كلمة المرور الجديدة</label>
                    <div className="relative">
                        <Lock size={18} className="absolute top-3.5 right-4 text-slate-400" />
                        <input required type="password" className="w-full p-3 pr-12 rounded-xl bg-[#eef0f4] shadow-inner outline-none" value={secForm.confirmPassword} onChange={e => setSecForm({...secForm, confirmPassword: e.target.value})} />
                    </div>
                </div>

                <NeuButton type="submit" variant="primary" className="w-full" icon={<CheckCircle size={18} />}>
                    تحديث بيانات الأمان
                </NeuButton>
            </form>
        </GlassCard>
      ) : (
        <GlassCard className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 rounded-xl bg-blue-50 border border-blue-100 flex flex-col gap-4">
                    <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                        <Download size={24} />
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-700 text-lg">نسخ احتياطي</h3>
                        <p className="text-sm text-slate-500 mt-1">تنزيل نسخة كاملة من قاعدة البيانات (المنتجات، الفواتير، الموظفين) كملف JSON.</p>
                    </div>
                    <NeuButton onClick={handleBackup} className="w-full mt-auto bg-white text-blue-600 border border-blue-200">
                        تنزيل النسخة الاحتياطية
                    </NeuButton>
                </div>

                <div className="p-6 rounded-xl bg-red-50 border border-red-100 flex flex-col gap-4">
                    <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600">
                        <AlertTriangle size={24} />
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-700 text-lg">إعادة ضبط المصنع</h3>
                        <p className="text-sm text-slate-500 mt-1">حذف جميع البيانات والبدء من جديد. لا يمكن التراجع عن هذا الإجراء.</p>
                    </div>
                    <NeuButton onClick={handleFactoryReset} variant="danger" className="w-full mt-auto">
                        حذف كل البيانات
                    </NeuButton>
                </div>
            </div>
        </GlassCard>
      )}
    </div>
  );
};

export default Settings;
