
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/dbService';
import { Technician } from '../types';
import { GlassCard } from '../components/GlassCard';
import { NeuButton } from '../components/NeuButton';
import { Plus, Edit, Trash, X, Phone, Briefcase, User } from 'lucide-react';

const Technicians = () => {
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTech, setEditingTech] = useState<Technician | null>(null);
  
  const initialForm = { name: '', phone: '', specialization: '', dailyRate: 0, notes: '' };
  const [formData, setFormData] = useState(initialForm);

  useEffect(() => {
    setTechnicians(dbService.getTechnicians());
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const techToSave: Technician = {
      id: editingTech ? editingTech.id : '', // Service handles new ID logic if empty
      ...formData
    };
    
    dbService.saveTechnician(techToSave);
    setTechnicians(dbService.getTechnicians());
    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if(confirm('هل أنت متأكد من حذف هذا السجل؟')) {
      dbService.deleteTechnician(id);
      setTechnicians(dbService.getTechnicians());
    }
  };

  const openEdit = (t: Technician) => {
    setEditingTech(t);
    setFormData({ 
      name: t.name, 
      phone: t.phone, 
      specialization: t.specialization, 
      dailyRate: t.dailyRate || 0, 
      notes: t.notes || '' 
    });
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTech(null);
    setFormData(initialForm);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-700">إدارة الصنايعية والفنيين</h2>
        <NeuButton variant="primary" icon={<Plus size={18}/>} onClick={() => setIsModalOpen(true)}>
          إضافة صنايعي
        </NeuButton>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {technicians.length === 0 ? (
             <GlassCard className="col-span-full flex flex-col items-center justify-center py-12 text-slate-400">
                <User size={48} className="mb-4 opacity-50" />
                <p>لا يوجد صنايعية مسجلين.</p>
             </GlassCard>
        ) : (
            technicians.map((tech) => (
            <GlassCard key={tech.id} className="flex flex-col gap-3 group relative">
                <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 shadow-inner flex items-center justify-center text-slate-500">
                            <User size={24} />
                        </div>
                        <div>
                            <h3 className="font-bold text-slate-700 text-lg">{tech.name}</h3>
                            <div className="flex items-center gap-1 text-fas-600 text-sm font-semibold">
                                <Briefcase size={14} />
                                <span>{tech.specialization}</span>
                            </div>
                        </div>
                    </div>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity absolute left-4 top-4 bg-white/80 p-1 rounded-lg shadow-sm backdrop-blur-sm">
                        <button onClick={() => openEdit(tech)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md">
                            <Edit size={16} />
                        </button>
                        <button onClick={() => handleDelete(tech.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-md">
                            <Trash size={16} />
                        </button>
                    </div>
                </div>
                
                <div className="pt-3 border-t border-slate-100/50 space-y-2 text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                        <Phone size={16} className="text-slate-400" />
                        <span dir="ltr" className="text-right">{tech.phone}</span>
                    </div>
                    {tech.dailyRate && tech.dailyRate > 0 && (
                        <div className="flex items-center justify-between">
                            <span className="text-slate-400 text-xs">اليومية التقريبية:</span>
                            <span className="font-bold">{tech.dailyRate} ج.م</span>
                        </div>
                    )}
                    {tech.notes && (
                        <p className="text-xs text-slate-400 italic mt-2 bg-white/40 p-2 rounded-lg">
                            "{tech.notes}"
                        </p>
                    )}
                </div>
            </GlassCard>
            ))
        )}
      </div>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/20 backdrop-blur-sm p-4">
          <GlassCard className="w-full max-w-lg relative !bg-[#eef0f4]">
            <button onClick={handleCloseModal} className="absolute top-4 left-4 text-slate-400 hover:text-slate-600">
              <X size={24} />
            </button>
            <h3 className="text-xl font-bold mb-6 text-slate-700">{editingTech ? 'تعديل بيانات صنايعي' : 'إضافة صنايعي جديد'}</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">الاسم</label>
                    <input required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">التخصص</label>
                    <input placeholder="نجار، سباك..." required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.specialization} onChange={e => setFormData({...formData, specialization: e.target.value})} />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">رقم الهاتف</label>
                    <input required className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1">اليومية (اختياري)</label>
                    <input type="number" className="w-full p-3 rounded-xl bg-white shadow-inner outline-none" value={formData.dailyRate} onChange={e => setFormData({...formData, dailyRate: Number(e.target.value)})} />
                </div>
              </div>

              <div>
                 <label className="text-xs font-bold text-slate-500 block mb-1">ملاحظات</label>
                 <textarea className="w-full p-3 rounded-xl bg-white shadow-inner outline-none h-20 resize-none" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} />
              </div>

              <div className="pt-4 flex gap-3">
                <NeuButton type="submit" variant="primary" className="flex-1">حفظ</NeuButton>
                <NeuButton type="button" onClick={handleCloseModal} className="flex-1">إلغاء</NeuButton>
              </div>
            </form>
          </GlassCard>
        </div>
      )}
    </div>
  );
};

export default Technicians;
