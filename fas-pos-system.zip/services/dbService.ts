
import { Product, User, UserRole, Invoice, Expense, AppSettings, Technician, Employee, Project, PayrollRecord } from '../types';

// Keys for LocalStorage
const KEYS = {
  USERS: 'fas_users',
  PRODUCTS: 'fas_products',
  INVOICES: 'fas_invoices',
  EXPENSES: 'fas_expenses',
  SETTINGS: 'fas_settings',
  TECHNICIANS: 'fas_technicians',
  EMPLOYEES: 'fas_employees',
  PROJECTS: 'fas_projects',
  PAYROLL: 'fas_payroll',
};

// Initial Data Seeding
const seedData = () => {
  if (!localStorage.getItem(KEYS.USERS)) {
    const admin: User = {
      id: '1',
      username: 'admin',
      passwordHash: 'password', // In production, use bcrypt
      role: UserRole.ADMIN,
      fullName: 'System Administrator'
    };
    const cashier: User = {
        id: '2',
        username: 'cashier',
        passwordHash: '123456',
        role: UserRole.CASHIER,
        fullName: 'John Doe'
      };
    localStorage.setItem(KEYS.USERS, JSON.stringify([admin, cashier]));
  }

  if (!localStorage.getItem(KEYS.PRODUCTS)) {
    const products: Product[] = [
      { id: '101', name: 'Premium Wood Panel', category: 'Wood', price: 1200, cost: 800, stock: 50, minStockAlert: 10, barcode: '1001' },
      { id: '102', name: 'White Matte Paint (Gallon)', category: 'Paint', price: 450, cost: 300, stock: 20, minStockAlert: 5, barcode: '1002' },
      { id: '103', name: 'Ceramic Tile 60x60', category: 'Finishing', price: 250, cost: 180, stock: 500, minStockAlert: 50, barcode: '1003' },
      { id: '104', name: 'Door Handle - Gold', category: 'Hardware', price: 150, cost: 80, stock: 30, minStockAlert: 5, barcode: '1004' },
    ];
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  }

  if (!localStorage.getItem(KEYS.SETTINGS)) {
    const settings: AppSettings = {
      currency: 'EGP',
      taxRate: 0.14,
      companyName: 'FAS - Fekrah Architectural Solutions',
      companyAddress: 'Cairo, Egypt',
      companyPhone: '+20 123 456 7890',
      printerType: 'THERMAL'
    };
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
  }

  if (!localStorage.getItem(KEYS.INVOICES)) localStorage.setItem(KEYS.INVOICES, JSON.stringify([]));
  if (!localStorage.getItem(KEYS.EXPENSES)) localStorage.setItem(KEYS.EXPENSES, JSON.stringify([]));
  if (!localStorage.getItem(KEYS.TECHNICIANS)) localStorage.setItem(KEYS.TECHNICIANS, JSON.stringify([]));
  if (!localStorage.getItem(KEYS.EMPLOYEES)) localStorage.setItem(KEYS.EMPLOYEES, JSON.stringify([]));
  if (!localStorage.getItem(KEYS.PROJECTS)) localStorage.setItem(KEYS.PROJECTS, JSON.stringify([]));
  if (!localStorage.getItem(KEYS.PAYROLL)) localStorage.setItem(KEYS.PAYROLL, JSON.stringify([]));
};

// Initialize immediately
seedData();

// Helper generic Get/Set
const getItems = <T>(key: string): T[] => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

const setItems = <T>(key: string, items: T[]) => {
  localStorage.setItem(key, JSON.stringify(items));
};

export const dbService = {
  // Products
  getProducts: () => getItems<Product>(KEYS.PRODUCTS),
  saveProduct: (product: Product) => {
    const products = getItems<Product>(KEYS.PRODUCTS);
    const index = products.findIndex(p => p.id === product.id);
    if (index >= 0) {
      products[index] = product;
    } else {
      products.push({ ...product, id: Date.now().toString() });
    }
    setItems(KEYS.PRODUCTS, products);
  },
  deleteProduct: (id: string) => {
    const products = getItems<Product>(KEYS.PRODUCTS).filter(p => p.id !== id);
    setItems(KEYS.PRODUCTS, products);
  },
  updateStock: (id: string, quantity: number) => {
      const products = getItems<Product>(KEYS.PRODUCTS);
      const product = products.find(p => p.id === id);
      if(product) {
          product.stock -= quantity;
          setItems(KEYS.PRODUCTS, products);
      }
  },
  getLowStockProducts: () => {
    const products = getItems<Product>(KEYS.PRODUCTS);
    return products.filter(p => p.stock <= p.minStockAlert);
  },

  // Invoices
  createInvoice: (invoice: Invoice) => {
    const invoices = getItems<Invoice>(KEYS.INVOICES);
    invoices.push(invoice);
    setItems(KEYS.INVOICES, invoices);
    
    // Update Stock
    invoice.items.forEach(item => {
        dbService.updateStock(item.id, item.quantity);
    });
  },
  getInvoices: () => getItems<Invoice>(KEYS.INVOICES),

  // Users (Login & Management)
  login: (username: string, password: string): User | null => {
    const users = getItems<User>(KEYS.USERS);
    const user = users.find(u => u.username === username && u.passwordHash === password);
    return user || null;
  },
  updateUserCredentials: (userId: string, newUsername: string, newPasswordHash: string) => {
    const users = getItems<User>(KEYS.USERS);
    const index = users.findIndex(u => u.id === userId);
    if (index >= 0) {
      users[index].username = newUsername;
      users[index].passwordHash = newPasswordHash;
      setItems(KEYS.USERS, users);
      return users[index];
    }
    return null;
  },
  getCurrentUser: (id: string) => {
    const users = getItems<User>(KEYS.USERS);
    return users.find(u => u.id === id);
  },

  // Expenses
  addExpense: (expense: Expense) => {
      const expenses = getItems<Expense>(KEYS.EXPENSES);
      expenses.push({ ...expense, id: Date.now().toString() });
      setItems(KEYS.EXPENSES, expenses);
  },
  getExpenses: () => getItems<Expense>(KEYS.EXPENSES),
  getProjectExpenses: (projectId: string) => {
    const expenses = getItems<Expense>(KEYS.EXPENSES);
    return expenses.filter(e => e.projectId === projectId);
  },

  // Technicians
  getTechnicians: () => getItems<Technician>(KEYS.TECHNICIANS),
  saveTechnician: (tech: Technician) => {
    const techs = getItems<Technician>(KEYS.TECHNICIANS);
    const index = techs.findIndex(t => t.id === tech.id);
    if (index >= 0) {
      techs[index] = tech;
    } else {
      techs.push({ ...tech, id: Date.now().toString() });
    }
    setItems(KEYS.TECHNICIANS, techs);
  },
  deleteTechnician: (id: string) => {
    const techs = getItems<Technician>(KEYS.TECHNICIANS).filter(t => t.id !== id);
    setItems(KEYS.TECHNICIANS, techs);
  },

  // --- HR & Finance Services ---

  // Employees
  getEmployees: () => getItems<Employee>(KEYS.EMPLOYEES),
  saveEmployee: (emp: Employee) => {
    const employees = getItems<Employee>(KEYS.EMPLOYEES);
    const index = employees.findIndex(e => e.id === emp.id);
    if (index >= 0) {
      employees[index] = emp;
    } else {
      employees.push({ ...emp, id: Date.now().toString() });
    }
    setItems(KEYS.EMPLOYEES, employees);
  },
  deleteEmployee: (id: string) => {
    const employees = getItems<Employee>(KEYS.EMPLOYEES).filter(e => e.id !== id);
    setItems(KEYS.EMPLOYEES, employees);
  },
  addLoan: (empId: string, amount: number) => {
    const employees = getItems<Employee>(KEYS.EMPLOYEES);
    const emp = employees.find(e => e.id === empId);
    if (emp) {
      emp.loanBalance += amount;
      setItems(KEYS.EMPLOYEES, employees);
    }
  },

  // Projects
  getProjects: () => getItems<Project>(KEYS.PROJECTS),
  saveProject: (proj: Project) => {
    const projects = getItems<Project>(KEYS.PROJECTS);
    const index = projects.findIndex(p => p.id === proj.id);
    if (index >= 0) {
      projects[index] = proj;
    } else {
      projects.push({ ...proj, id: Date.now().toString() });
    }
    setItems(KEYS.PROJECTS, projects);
  },
  addProjectIncome: (projId: string, amount: number) => {
    const projects = getItems<Project>(KEYS.PROJECTS);
    const proj = projects.find(p => p.id === projId);
    if (proj) {
      proj.totalIncome += amount;
      setItems(KEYS.PROJECTS, projects);
    }
  },

  // Payroll
  getPayroll: () => getItems<PayrollRecord>(KEYS.PAYROLL),
  savePayrollRecord: (record: PayrollRecord) => {
    const records = getItems<PayrollRecord>(KEYS.PAYROLL);
    records.push(record);
    setItems(KEYS.PAYROLL, records);

    // Automatically reduce employee loan if deduction exists
    if (record.loanDeduction > 0) {
      const employees = getItems<Employee>(KEYS.EMPLOYEES);
      const emp = employees.find(e => e.id === record.employeeId);
      if (emp) {
        emp.loanBalance = Math.max(0, emp.loanBalance - record.loanDeduction);
        setItems(KEYS.EMPLOYEES, employees);
      }
    }

    // Automatically create an expense record for the salary
    dbService.addExpense({
      id: Date.now().toString(),
      title: `راتب شهر ${record.month} - ${record.employeeName}`,
      amount: record.netSalary,
      category: 'رواتب',
      date: new Date().toISOString(),
      notes: 'دفع رواتب تلقائي'
    });
  },

  // Settings
  getSettings: (): AppSettings => {
      const data = localStorage.getItem(KEYS.SETTINGS);
      return data ? JSON.parse(data) : {
        currency: 'EGP', taxRate: 0.14, companyName: 'FAS', companyAddress: '', companyPhone: '', printerType: 'THERMAL'
      };
  },
  saveSettings: (settings: AppSettings) => {
      localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
  }
};
