
export enum UserRole {
  ADMIN = 'ADMIN',
  CASHIER = 'CASHIER'
}

export interface User {
  id: string;
  username: string;
  passwordHash: string; // In real app use bcrypt, here mock
  role: UserRole;
  fullName: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  minStockAlert: number;
  barcode: string;
  imageUrl?: string;
}

export interface CartItem extends Product {
  quantity: number;
  discount: number; // Percentage
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string; // ISO String
  cashierId: string;
  cashierName: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: 'CASH' | 'CARD' | 'MIXED';
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: string;
  date: string;
  notes?: string;
  projectId?: string; // Linked to a project
  projectName?: string; // Denormalized for display
}

export interface Technician {
  id: string;
  name: string;
  phone: string;
  specialization: string; // e.g., Carpenter, Painter
  dailyRate?: number;
  notes?: string;
}

export interface AppSettings {
  currency: string;
  taxRate: number;
  companyName: string;
  companyAddress: string;
  companyPhone: string;
  printerType: 'A4' | 'THERMAL';
  companyLogo?: string;
}

// --- HR & Finance Types ---

export interface Employee {
  id: string;
  name: string;
  role: string; // Accountant, Engineer, Laborer
  phone: string;
  baseSalary: number;
  photo?: string; // Base64
  joinDate: string;
  loanBalance: number; // Current loans
  nationalId?: string;
  email?: string;
}

export interface Project {
  id: string;
  name: string;
  clientName: string;
  status: 'ACTIVE' | 'COMPLETED' | 'PENDING';
  budget: number; // Estimated budget
  totalIncome: number; // Money received
  startDate: string;
  description?: string;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // Payment Date
  month: string; // e.g. "2023-10"
  baseSalary: number;
  absentDays: number;
  deductionAmount: number; // Calculated from absence
  loanDeduction: number; // Repayment of loans
  transportAllowance: number; // "Mashawir"
  bonuses: number;
  netSalary: number;
}
